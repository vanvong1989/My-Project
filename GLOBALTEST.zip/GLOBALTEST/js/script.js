document.addEventListener("DOMContentLoaded", function(){

	var nut = document.querySelectorAll('.chuyenslide ul li');
	var slides = document.querySelectorAll('.cacslide ul li');
	
	for (var i = 0; i < nut.length; i++) {
	 nut[i].addEventListener('click', function() {
	 	for (var i = 0; i < nut.length; i++) {
	 	 nut[i].classList.remove('kichhoat');
	 	}
	    this.classList.add('kichhoat');

	    var nutkichhoat = this;
	    var vitrinut  = 0;
	    for (vitrinut = 0; nutkichhoat = nutkichhoat.previousElementSibling; vitrinut++)

	    	for (var i = 0; i < slides.length; i++) {
	    		slides[i].classList.remove('active');
	    		slides[vitrinut].classList.add('active');

	    	}
	 })
	}
})